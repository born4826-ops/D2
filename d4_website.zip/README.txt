D4 — Demo investment-style website
Files:
- index.html
- styles.css
- script.js

Instructions:
1. Open index.html in a browser to preview locally.
2. To publish on GitHub Pages:
   - Create repo named 'd4'.
   - Upload these files to the repo root.
   - Enable GitHub Pages on the main branch.
   - Your site will be at https://<yourusername>.github.io/d4/
