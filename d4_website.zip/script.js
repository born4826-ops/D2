
// Minimal interactive behavior for the demo site.
document.getElementById('menuToggle')?.addEventListener('click', function(){
  const nav = document.querySelector('.nav');
  if(!nav) return;
  nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
});

const loginBtn = document.getElementById('loginBtn');
const loginModal = document.getElementById('loginModal');
const closeModal = document.getElementById('closeModal');
const doLogin = document.getElementById('doLogin');

loginBtn?.addEventListener('click', function(e){
  e.preventDefault();
  loginModal.classList.remove('hidden');
});

closeModal?.addEventListener('click', function(){ loginModal.classList.add('hidden'); });

doLogin?.addEventListener('click', function(){
  // Static demo login. Replace with your backend.
  const email = document.getElementById('email').value;
  if(!email){ alert('enter email'); return; }
  alert('Demo login for ' + email);
  loginModal.classList.add('hidden');
});

// Small demo: animate numbers (not live data)
function animateValue(id, start, end, duration) {
  const obj = document.getElementById(id);
  if(!obj) return;
  let startTime = null;
  function step(timestamp){
    if(!startTime) startTime = timestamp;
    const progress = Math.min((timestamp - startTime) / duration, 1);
    const value = start + (end - start) * progress;
    obj.textContent = '$' + value.toFixed(2);
    if(progress < 1) window.requestAnimationFrame(step);
  }
  window.requestAnimationFrame(step);
}
animateValue('totalValue', 9000, 12450, 800);
